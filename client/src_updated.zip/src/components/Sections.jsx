// src/components/Sections.jsx
import { lazy } from "react";
const Poster = lazy(() => import("@components/setting/Poster"));
const PosterWrapper = lazy(() => import("@components/setting/PosterWrapper"));
const Map = lazy(() => import("@components/setting/Map"));
const Content = lazy(() => import("@components/setting/Content"));
const Message = lazy(() => import("@components/setting/Message"));
const Title = lazy(() => import("@components/setting/Title"));
const Address = lazy(() => import("@components/setting/Address"));
const Date = lazy(() => import("@components/setting/Date"));
const Coordinate = lazy(() => import("@components/setting/Coordinate"));

const Sections = ({
  drawerMode,
  styles,
  setStyles,
  fontFamilies,
  updateSectionStyle,
  content,
  onChangeContent,
}) => {
  return (
    <>
      {drawerMode === "poster" ? (
        <Poster
          styles={styles}
          setStyles={setStyles}
          fontFamilies={fontFamilies}
        />
      ) : drawerMode === "posterWrapper" ? (
        <PosterWrapper
          styles={styles}
          setStyles={setStyles}
          fontFamilies={fontFamilies}
        />
      ) : drawerMode === "map" ? (
        <Map
          styles={styles}
          setStyles={setStyles}
          fontFamilies={fontFamilies}
        />
      ) : drawerMode === "content" ? (
        <Content
          content={content}
          onChangeContent={onChangeContent}
          styles={styles}
          setStyles={setStyles}
          fontFamilies={fontFamilies}
        />
      ) : drawerMode === "message" ? (
        <Message
          styles={styles}
          setStyles={setStyles}
          fontFamilies={fontFamilies}
        />
      ) : drawerMode === "title" ? (
        <Title
          styles={styles}
          setStyles={setStyles}
          fontFamilies={fontFamilies}
        />
      ) : drawerMode === "address" ? (
        <Address
          styles={styles}
          setStyles={setStyles}
          fontFamilies={fontFamilies}
        />
      ) : drawerMode === "date" ? (
        <Date
          styles={styles}
          setStyles={setStyles}
          fontFamilies={fontFamilies}
        />
      ) : drawerMode === "coordinate" ? (
        <Coordinate
          styles={styles}
          setStyles={setStyles}
          fontFamilies={fontFamilies}
        />
      ) : null}
    </>
  );
};

export default Sections;
